This is a small experiment. 
I used ChatGPT to make an ai_helper.

To use:
you must install flask, sql, groq and python
get an API code from Groq

To run, go to the folder in Terminal and run python main.py.
You must be online.

This is still a rough project, it was originally OpenAI but moved to Groq.

Second draft ai_helper, 4-14-26