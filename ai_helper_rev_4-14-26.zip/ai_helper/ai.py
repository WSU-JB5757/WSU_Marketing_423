from groq import Groq
import os
from dotenv import load_dotenv

# 👇 force absolute path
load_dotenv(dotenv_path=r".env")

api_key = os.getenv("GROQ_API_KEY")

print("DEBUG:", api_key)  # keep this for now

if not api_key:
    raise ValueError("GROQ_API_KEY not found. Check your .env file.")

client = Groq(api_key=api_key)

def generate_plan(goal):
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": "You are a helpful planner."},
            {"role": "user", "content": f"Create a short day-by-day plan for: {goal}"}
        ]
    )
    return response.choices[0].message.content