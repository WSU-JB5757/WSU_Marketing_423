import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta

from ai import generate_plan
from db import save_task, get_tasks
from reminders import schedule_email

def create_plan():
    goal = entry.get()

    if not goal:
        messagebox.showwarning("Input Error", "Enter a goal")
        return

    plan = generate_plan(goal)
    text_output.delete("1.0", tk.END)
    text_output.insert(tk.END, plan)

    save_task(goal, plan)

def schedule_reminder():
    plan = text_output.get("1.0", tk.END)

    if not plan.strip():
        messagebox.showwarning("Error", "No plan to schedule")
        return

    run_time = datetime.now() + timedelta(minutes=1)  # test: sends in 1 min
    schedule_email(run_time, "Task Reminder", plan)

    messagebox.showinfo("Scheduled", "Reminder set for 1 minute from now")

def load_tasks():
    tasks = get_tasks()
    text_output.delete("1.0", tk.END)

    for t in tasks:
        text_output.insert(tk.END, f"\nGoal: {t[1]}\nPlan:\n{t[2]}\n{'-'*40}\n")

# UI
root = tk.Tk()
root.title("AI Task Helper")

tk.Label(root, text="Enter Goal:").pack()

entry = tk.Entry(root, width=50)
entry.pack()

tk.Button(root, text="Generate Plan", command=create_plan).pack()
tk.Button(root, text="Schedule Reminder (1 min test)", command=schedule_reminder).pack()
tk.Button(root, text="Load Saved Tasks", command=load_tasks).pack()

text_output = tk.Text(root, height=20, width=60)
text_output.pack()

root.mainloop()