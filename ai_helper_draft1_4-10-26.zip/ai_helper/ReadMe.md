This is a small experiment. 
I used ChatGPT to make an ai_helper.

To use:
you must install flask, sql and python
get an API code from OpenAI
have a gmail account
get an app password for gmail
have money on OpenAI, it's not expensive, but it's also not free.

The gmail, API code and app password go into the specified blanks in the .env
Never share this info or commit it to GitHub.

To run, go to the folder in Terminal and run python main.py.
You must be online and have money in the API account used.

This is still a rough project, and I intend to improve it, and move it to either Gemini or offline later.

First draft ai_helper, 4-10-26