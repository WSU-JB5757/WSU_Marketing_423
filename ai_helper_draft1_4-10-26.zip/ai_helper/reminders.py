from apscheduler.schedulers.background import BackgroundScheduler
import smtplib
from email.message import EmailMessage
import os
from dotenv import load_dotenv

load_dotenv()

scheduler = BackgroundScheduler()
scheduler.start()

def send_email(subject, body):
    msg = EmailMessage()
    msg.set_content(body)
    msg['Subject'] = subject
    msg['From'] = os.getenv("EMAIL_ADDRESS")
    msg['To'] = os.getenv("EMAIL_ADDRESS")

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(os.getenv("EMAIL_ADDRESS"), os.getenv("EMAIL_PASSWORD"))
        smtp.send_message(msg)

def schedule_email(run_time, subject, body):
    scheduler.add_job(send_email, 'date', run_date=run_time, args=[subject, body])