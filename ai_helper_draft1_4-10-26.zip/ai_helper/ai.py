import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_plan(goal):
    response = client.chat.completions.create(
        model="gpt-40-mini",
        messages=[
            {"role": "system", "content": "You are a helpful planner."},
            {"role": "user", "content": f"Create a short day-by-day plan for: {goal}"}
        ]
    )
    return response.choices[0].message.content