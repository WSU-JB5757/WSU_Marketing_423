import sqlite3

conn = sqlite3.connect("tasks.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal TEXT,
    plan TEXT
)
""")

conn.commit()

def save_task(goal, plan):
    cursor.execute("INSERT INTO tasks (goal, plan) VALUES (?, ?)", (goal, plan))
    conn.commit()

def get_tasks():
    cursor.execute("SELECT * FROM tasks")
    return cursor.fetchall()